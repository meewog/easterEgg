// function trigger()
// {
// 	var width  = 480;
// 	var height = 640;
// 	var pages  = [ "pic1.jpg", "pic2.jpg"];
// 	var book = new Book("turnThePage", width, height, pages);
// }